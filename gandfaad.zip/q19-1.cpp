#include<iostream>
using namespace std;
#define max 10
class graph
{
    int a[max][max];
    int b[max][max];
    int size;
public:
	graph();
	void euler(int);
	void display();
	void define();
};
   graph::graph() 
    {
        for (int i=0; i<max; i++)
            for(int j=0; j<max; j++)
                a[i][j]=0;
        size=0;
    }

    void graph::define()
    {
        int t,x,y;
        cout<<"Enter the type of Graph \n1. Directed \t 2. Undirected";
        cin>>t;
        cout<<" Enter no. of Vertices";
        cin>>size;
        cout<<"\n first vertex";
        cin>>x;
        cout<<"\n second vertex";
        cin>>y;
        while(x!=-1 && y!=-1 && x-1<size && y-1<size && x>0 && y>0)
        {
            a[x-1][y-1]=1;
            if(t==2)
                a[y-1][x-1]=1;
            cout<<"\n first vertex";
            cin>>x;
            cout<<"\n second vertex";
            cin>>y;
        }
        for (int i=0; i<size; i++)
        {
            for(int j=0; j<size; j++)
                b[i][j]=a[i][j];
        }
        euler(t);

    }
    void graph::display()
    {
       
        for (int i=0; i<size; i++)
        {
            cout<<endl;

            for(int j=0; j<size; j++)
                cout<<" "<<a[i][j];
        }
    }
    void graph::euler(int t)
    {
        int c[max];
        int s=0,n=0;
        cout<<"/n Enter Path, -1 to stop";
        cin>>n;
        while(n!=-1)
        {

            c[s++]=n;
            cin>>n;
        }
        bool f=true;
      
        for(int i=0; i<s-1; ++i)
        {
            if(b[c[i]-1][c[i+1]-1]!=1)
                f=false;
            else
            {
                b[c[i]-1][c[i+1]-1]=0;
                if(t==2)
                    b[c[i+1]-1][c[i]-1]=0;
            }
        }

        for (int i=0; i<size; i++)
        {

            for(int j=0; j<size; j++)
                if(b[i][j]!=0)
                    f=false;

        }

        if(f)
        {
            if(c[0]==c[s-1])
                cout<<"\nEuler Circuit";
            else
                cout<<"\nEuler Path";
        }
        else
            cout<<"\nNot an Euler Path";
    }




int main()
{
    graph g;
    g.define();
    g.display();
}
