#include<iostream>
#include<cmath>
using namespace std;  
void card(int);
void powerset(int [],int);
bool ismember(int ,int [], int);
int main()
{
	int A[20],i=0,c,k;
	char ch;
	cout<<"\n Enter First Element of Set A ";
	
	do{  
		cin>>A[i++];
		cout<<"\n Do you want to enter more element in set A(y/n)?";
		cin>>ch;
	}while(ch=='y'||ch=='Y');
	
	do{
		cout<<"\n 1. Cardinality ";
		cout<<"\n 2. Power set ";
		cout<<"\n 3. Ismember ";
		cout<<"\n\n  Enter Your Choice :";
		cin>>c;
		switch(c)
		{
			case 1: card(i); break;
			case 2: powerset(A,i);	 break;
			case 3: {
					cout<<"\n Enter the element to search ";
					cin>>k;
					bool status=ismember(k,A,i);
					if(status==1)
						cout<<"\n Element is present ";
					else 
						cout<<"\n element not present ";
		
				   }				break;
			
			default : cout<<"  \n Wrong Choice";
		}
		cout<<"\n Want to goto menu again ";
		cin>>ch;
	}while(ch=='y'||ch=='Y');
	cout<<"\n THE END\n\n";
		
	return 0;
}

void card(int s)
{ 	
	cout<<"\n Cardinality of given array is="<<s<<"\n";
}
		
void powerset(int A[],int s)
{	
	int Ps,count=0,i,j,run,zero=0;
	int bin[20];
	Ps=pow(2,s);
	while(count<Ps)
	{		run=count;
			count++;
			for(j=(s-1);j>=0;j--)
			{
				bin[j]=run%2;
				run=run/2;
			}
			cout<<endl;
	cout<<"(";	
	for(i=0;i<s;i++)
	{	if(bin[i]==1)
		{	
			cout<<A[i]<<" ";
		}
	}
	cout<<")";
	}
}	

bool ismember(int a,int A[],int s)
{
	int i;
	for(i=0;i<s;i++)
	{
		if(A[i]==a)
		return true;
	}
	
	return false;
}
