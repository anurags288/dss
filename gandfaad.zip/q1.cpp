
#include<iostream>
using namespace std;

int main()
{  
   int a[20],i=0;
char ch='y';

while(ch=='y')
{
  cout<<"enter element "<<i+1<<" "<<endl;
  cin>>a[i];
i++;
cout<<"want to add more elements?(y/n)"<<endl;
cin>>ch;
}

cout<<"cardinality of the set is "<<i<<endl;
int b;
cout<<"enter any integer ";
cin>>b;
int f=0;
for(int k=0;k<=i;k++)
{ if(a[k]==b)
  f=1;
}

if(f==1)
cout<<"the entered element is a member of the entered set "<<endl;
else
cout<<"the entered element is not present in the entered set "<<endl;


cout<<endl;
return 0;
}

