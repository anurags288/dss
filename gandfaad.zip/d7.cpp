#include<iostream>
using namespace std;
bool bin(int arr[],int l,int n,int x)
{
  if(l<=n)
  {
  int mid=(l+n)/2;
  if(arr[mid]==x)
  return true;
  else if(arr[mid]>x)
  bin(arr,l,mid-1,x);
  else
  bin(arr,mid+1,n,x);  
  }
  else
  return false;
}
int main()
{
	int a,l=0,x;
	cout<<"Enter the size of array";
	cin>>a;
	int arr[a];
	for(int i=0;i<a;i++)
	{
		cout<<"\n Enter the array element "<<(i+1);
		cin>>arr[i];
	}
	cout<<"Enter the number to be searched";
	cin>>x;
   bool r=bin(arr,l,a-1,x);
   if(r==true)
   cout<<"\n Number  found";
   else 
   cout<<"\n Number not Found";
}
