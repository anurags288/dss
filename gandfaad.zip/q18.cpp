#include<iostream>
using namespace std;
#define Max 10
class graph
{
private:
    int b[Max][Max];
    int a[Max][Max];
    int size;
public:
    graph()
    {
        for(int i=0; i<Max; ++i)
            for(int j=0; j<Max; ++j)
            {
                a[i][j]=b[i][j]=0;
                if(i==j)
                    b[i][j]=1;
            }
        size=0;
    }
    void input()
    {
        int x=0;
        int y=0;
        int ch=0;
        cout<<"\n Enter the type of Graph \n\n \t 1. Directed \t\t 2. Undirected";
        cin>>ch;
        cout<<"\nEnter the number of vertices in the graph:";
        cin>>size;

        cout<<"\nEnter the first vertex:";
        cin>>x;
        cout<<"\nEnter the second vertex:";
        cin>>y;
        while(x!=-1&&y!=-1&&x>0&&x-1<size&&y>0&&y-1<size)
        {
            a[x-1][y-1]=1;
            if(ch==2)
                a[y-1][x-1]=1;
            cout<<"\nEnter the first vertex:";
            cin>>x;
            cout<<"\nEnter the second vertex:";
            cin>>y;
        }
    }
    void multiply(int n)
    {
        if(n==0)
            ;
        else
        {
            int sum=0;
            int temp[size][size];
            for(int i=0; i<size; ++i)
                for(int j=0; j<size; ++j)
                {
                    for(int k=0; k<size; ++k)
                        sum+=b[i][k]*a[k][j];
                    temp[i][j]=sum;
                    sum=0;
                }
            for(int i=0; i<size; ++i)
                for(int j=0; j<size; ++j)
                    b[i][j]=temp[i][j];
            multiply(n-1);
        }
    }
    int getpath(int i,int j)
    {
        return b[i-1][j-1];

    }
    void display()
    { cout<<"\n\t\t\t\t\t\t\t\t\t\t\t";
        for(int i=0; i<size; ++i)
        {

            for(int j=0; j<size; ++j)
                cout<<" "<<a[i][j];
            cout<<endl;
        }
        cout<<endl<<endl;
        cout<<"\n\t\t\t\t\t\t\t\t\t\t\t";
        for(int i=0; i<size; ++i)
        {

            for(int j=0; j<size; ++j)
                cout<<" "<<b[i][j];
            cout<<endl;
        }
    }
};
int main()
{
    graph g;
    g.input();
    int a,b,n;
    cout<<"Enter starting vertex:";
    cin>>a;
    cout<<"Enter end vertex:";
    cin>>b;
    cout<<"Enter path length:";
    cin>>n;
    g.multiply(n);
    g.display();
    cout<<"The number of paths of length "<<n<<" are:"<<g.getpath(a,b);
    return 0;

}













