#include<iostream>
using namespace std;
class Adjacency
{
private:
int a[10][10];
int v;
public:
Adjacency()
{
v=0;
}


void input()
{
cout<<"\nEnter no.of vertices";
cin>>v;
int a[v][v];
}


void directed()
{
int i=1,j=1;
cout<<"\nForming the graph";
cout<<"\nEnter both vertices as 0  to exit";
while(i!=0&&j!=0)
{
cout<<"\nEnter the 1st vertex"; 
cin>>i;
cout<<"\nEnter the 2nd vertex"; 
cin>>j;
if(i<=v&&j<=v)
{
cout<<"\nEdge is valid\n";
a[i][j]=1;
}
else
cout<<"\nEdge is invalid\n";
}
for(int y=1;y<=v;y++)
{
for(int z=1;z<=v;z++)
{
if(a[y][z]!=1)
a[y][z]=0;
}
}
}



void undirected()
{
int i=1,j=1;
cout<<"\nForming the graph";
cout<<"\nEnter both vertices as 0  to exit";
while(i!=0&&j!=0)
{
cout<<"\nEnter the 1st vertex";
cin>>i;
cout<<"\nEnter the 2nd vertex"; 
cin>>j;
if(i<=v&&j<=v)
{
cout<<"\nEdge is valid\n";
a[i][j]=1;
a[j][i]=1;
}
else
cout<<"\nEdge is invalid\n";
}
for(int y=1;y<=v;y++)
{
for(int z=1;z<=v;z++)
{
if(a[y][z]!=1)
a[y][z]=0;
}
}
}


void check()
{
int chck=1;
for(int i=1;i<=v;i++)
{
   for(int j=1;j<=v;j++)
    {
      if(i==j)
      {
        if(a[i][j]==1)
        { 
         chck=0;
          break;
        }
      }
       else
        {
          if(a[i][j]==0)
           {
             chck=0;
             break;
           }
        }
     }
}
if(chck==1)
cout<<"\nComplete graph";
else
cout<<"\nIncomplete graph";
}


void print()
{
for(int i=1;i<=v;i++)
{
for(int j=1;j<=v;j++)
{
cout<<a[i][j]<<" ";
}
cout<<"\n";
}
}
};



int main()
{
int ch;
Adjacency ad;
ad.input();
do
{
cout<<"\n///MENU///";
cout<<"\n1:for directed graph";
cout<<"\n2:for undirected graph";
cout<<"\n0:exit";
cout<<"\nenter your choice";
cin>>ch;
switch(ch)
{
case 1:
{
ad.directed();
ad.print();
ad.check();
break;
}
case 2:
{
ad.undirected();
ad.print();
ad.check();
break;
}
case 0:
cout<<"termination";
break;
default:
cout<<"invalid input";
}
}while(ch!=0);
}









