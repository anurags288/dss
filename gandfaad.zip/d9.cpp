#include<iostream>
using namespace std;
int inser(int n,int arr[])
{
	
	for(int i=1;i<n;i++)
	{
		for(int j=0;j<i;j++)
		{
		
				if(arr[i]<arr[j])
			{
				int t=arr[i];
				arr[i]=arr[j];
				arr[j]=t;
			}
		}
	    	cout<<i<<"Iteration ";
		for(int k=0;k<n;k++)
		cout<<arr[k]<<" ";
		cout<<"--Number of iteration "<<(n-i);
		cout<<"\n";	
	}
}
int main()
{
	int a;
	int arr[a];
	cout<<"\n Enter the size of array ";
	cin>>a;
	
	cout<<"\n Enter elements :";
	for(int i=0;i<a;i++)
	{	
		cin>>arr[i];
	}
	inser(a,arr);
	cout<<"\n Sorted matrix:";
	for(int i=0;i<a;i++)
	{
		cout<<arr[i]<<" ";
	}
}
