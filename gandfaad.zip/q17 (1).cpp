#include<iostream>
using namespace std;
class InOut
{
private:
int a[20][20];
int v;
public:
InOut()
{
v=0;
}


void input()
{
cout<<"\nEnter no.of vertices";
cin>>v;
a[v][v];
for(int i=1;i<=v;i++)
{
for(int j=1;j<=v;j++)
{
a[i][j]=0;
}
}
}


void directed()
{
int i=1,j=1,m;
cout<<"\nForming the graph";
cout<<"\nEnter (0,0) to exit";
while(i!=0&&j!=0)
{
cout<<"\nEnter the 1st vertex"; 
cin>>i;
cout<<"\nEnter the 2nd vertex"; 
cin>>j;
cout<<"\nEnter multiplicity of edge"<<i<<"-"<<j;
cin>>m;
if(i<=v&&j<=v&&i!=0&&j!=0&&i!=j)
{
cout<<"\nEdge is valid\n";
a[i][j]=m;
}
else
cout<<"\nEdge is invalid\n";
}

}







void print()
{
for(int i=1;i<=v;i++)
{
for(int j=1;j<=v;j++)
{
cout<<a[i][j]<<" ";
}
cout<<"\n";
}
}



void calculate()
{
int i,j,c,f;
for(i=1;i<=v;i++)
{
c=0;f=0;
for(j=1;j<=v;j++)
{
c=c+a[i][j];
f+=a[j][i];
}
cout<<"\n Out Degree of"<<i<<"="<<c;
cout<<"\n In Degree of"<<i<<"="<<f;
}
}

};



int main()
{
int ch;
InOut ob;
ob.input();
ob.directed();
ob.print();
ob.calculate();
}



