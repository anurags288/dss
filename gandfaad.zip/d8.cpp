#include<iostream>
using namespace std;

int bubb(int n,int arr[])
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n-i-1;j++)
		{
			if(arr[j]>arr[j+1])
			{
				int t=arr[j];
				arr[j]=arr[j+1];
				arr[j+1]=t;
			}
		}
		 cout<<i<<"Iteration ";
		for(int k=0;k<n;k++)
		cout<<arr[k]<<" ";
		cout<<"--Number of iteration "<<(n-i);
		cout<<"\n";		
	}
	
}
int main()
{
	int i,n;
	cout<<"\n Enter the size of the matrix :";
	cin>>n;
	int arr[n];
	cout<<"\n Enter elements :";
	for(i=0;i<n;i++)
	{	
		cin>>arr[i];
	}
	bubb(n,arr);
	cout<<"\n Sorted matrix:";
	for(i=0;i<n;i++)
	{
		cout<<arr[i]<<" ";
	}
}
