#include<iostream>
using namespace std;
int fab(int n)
{
	if(n==1||n==0)
	return n;
	else 
	return (fab(n-1)+fab(n-2));
}
int main()
{
	cout<<"Enter the nth number";
	int a,i;
	cin>>a;
	for(i=0;i<a;i++)
	{
		cout<<fab(i)<<" ";
	}
}
