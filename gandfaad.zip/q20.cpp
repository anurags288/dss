#include<iostream>
using namespace std;
class Tree
{
private:
    int m;
public:
    void internalNodes(int i)
    {
        cout<<"\nNo of nodes:"<<m*i+1<<endl;

        cout<<"\nNo of leaves:"<<i*(m-1)+1<<endl;
    }
    void nodes(int n)
    {
        cout<<"\nNo of internal nodes:"<<(n-1)/m<<endl;
        cout<<"\nNo of leaves:"<<(n*(m-1)+1)/m<<endl;
    }
    void leaves(int l)
    {
        cout<<"\nNo of nodes:"<<(m*l-1)/(m-1)<<endl;
        cout<<"\nNo of internal nodes:"<<(l-1)/(m-1)<<endl;
    }
    void input()
    {
        int k;
        int ch;
        do
        {
            cout<<"1) Node\n2) Leaves\n3) Internal Nodes\n4) Exit\nEnter your choice:";
           
            cin>>ch;

            switch(ch)
            {
            case 1:
                cout<<"\nEnter the value of m ";
                cin>>m;
                cout<<"\nEnter the number of nodes ";
                cin>>k;
                if(k<=0||m<0||k>1&&k<m+1)
                    cout<<"\nWrong input";
                else
                    nodes(k);
                break;
            case 2:
                cout<<"\nEnter the value of m ";
                cin>>m;
                cout<<"\nEnter the number of leaves ";
                cin>>k;
                if(k==0)
                    cout<<"Number of nodes=1"<<endl;
                else if(k<0||m<0||(k>0&&k<m))
                    cout<<"\nWrong input";

                else
                    leaves(k);
                break;
            case 3:
                cout<<"\nEnter the value of m ";
                cin>>m;
                cout<<"\nEnter the number of internal nodes ";
                cin>>k;
                if(k<0||m<0)
                    cout<<"\nWrong input";
                else
                    internalNodes(k);
                break;
            case 4:
                
                break;
            default:
                cout<<"\nWrong choice ";
            }
        }
        while(ch!=4);

    }

};
int main()
{
    Tree t;
    t.input();
}

