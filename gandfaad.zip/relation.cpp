#include <iostream>
#include <sstream>
#include<stdlib.h>
using namespace std;
class relation
{
	private:
		int a[30][2];
		int b[50][50];
		int set[50];
		int l1;
		int l2;
	public:
		void setmatrix();
		int transitive();
		int reflexive();
		int symmetric();
		int antisymmetric();
};
void relation::setmatrix()
{
	cout << "Enter Set limit: ";
	cin >> l1;
	cout << endl;
	set[l1];
	b[l1][l1];
	int i,j;
	cout << "Enter Set: "; 
	for (i=0;i<l1;i++)
	cin >> set[i];
	//pos[i]=i;}
	cout << endl;
	int x=0,y,z,f=0;
	cout << "Enter Relation Pairs (Press -1 to exit)"<< endl;
	do
	{
		cout<< "Domain: ";
		cin >>y;
		cout << endl;
		a[x][0]=y;//relation
		if (y==-1)
		break;
		else
		{
			cout <<"Range: ";
			cin >> z;
			for (i=0;i<l1;i++)
			{
				if (set[i]==y)
				{
					for (j=0;j<l1;j++)
					if (set[j]==z)
					f=1;
				}
			}
			if (f==1)
			{
			cout << endl;
			a[x][1]=z;
		    }
		    else
		    {
		    	cout << "Not in set" << endl;
		    	exit(0);
			}
	    }
	    f=0;int py,pz;
	    for(int i=0;i<l1;i++)
	    { if(set[i]==y)
	       py=i;
	        if(set[i]==z)
	       pz=i;
	       }
		b[py][pz]=1;
		x++;
	}while(true);
	cout <<"Matrix:"<< endl;
	for(i=0;i<l1;i++)
	{
		cout<<endl;
		for(j=0;j<l1;j++)
		{
			cout << b[i][j] << " ";
		}
	}	
}
int relation::transitive()
{
	int t=1;
	int i,j,k;
	for(int i = 0;i<l1;i++)
       for(int j = 0;j<l1;j++)
         for(int k = 0;k<l1;k++)
           if(b[i][j] == 1 && b[j][k] == 1 && b[i][k] != 1)
             t= 0;
    
    return t;
}
int relation::reflexive()
{
	int i,j,t=1;
	for(int i = 0;i<l1;i++)
    {
       if(b[i][i] != 1)
       {
          t = 0;
          break;
       }
    }
    return t;
}
int relation::symmetric()
{
	int t=1,i,j;
	 for(int i = 0;i<l1;i++)
    {
       for(int j = 0;j<l1;j++)
       {
           if(b[i][j] != b[j][i])
        {
          t = 0;
          break;
        }
       }
    }
    return t;
}
int relation::antisymmetric()
{
	int i,j,t=1,f;
	for(int i = 0;i<l1;i++)
    {
       for(int j = 0;j<l1;j++)
       { if(i==j && b[i][j]==1)
         {f=0;
             }
       
         
         else if(i!=j)
         {  if(b[i][j] && b[j][i])
         {  f=1;}
       
         
       if(f==1)
       {t=0;}
       return t;
         
            
           
       
                }
       }
    }
    return t;
}
int main()
{
	relation r;
	int a,b,c,d;
	r.setmatrix();
	a=r.transitive();
	if (a==1)
	cout <<endl<< "TRANSITIVE" << endl;
	else
	cout <<endl<<"not transitive" << endl;
	b=r.reflexive();
	if (b==1)
	cout << "REFLEXIVE" << endl;
	else
	cout << "not reflexive" << endl;
	c=r.symmetric();
	if (c==1)
	cout << "SYMMETRIC" << endl;
	else
	cout << "not symmetric" << endl;
	d=r.antisymmetric();
	if (d==1)
	cout << "ANTISYMMETRIC" << endl;
	else
	cout << "not ANTIsymmetric" << endl;
	int h=0;
	if (a==1 && b==1 && c==1){
	cout <<"EQUIVALENT"<< endl;h++;}
	else
	cout <<"NOT EQUIVALENT"<< endl;
    if(a==1 && b==1 && d==1){
	cout <<"Partial Order"<< endl;h++;}
	else
	cout <<" NOT a Partial Order"<< endl;
	if (h==0)
	cout <<"NONE"<<endl;
	return 0;
	
}

